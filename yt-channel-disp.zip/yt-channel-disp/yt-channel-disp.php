
<?php
defined( 'ABSPATH' ) OR exit;
/**
 * Plugin Name
 *
 * @package           PluginPackage
 * @author            Houssem Eddine Mereghni
 * @copyright         2024
 * @license           GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:       Youtube Channel Display
 * Plugin URI:        
 * Description:       Display youtube channel on worpress made simple
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Houssem Eddine Mereghni
 * Author URI:        
 * Text Domain:       
 * License:           GPL v2 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Update URI:        
 * Requires Plugins:  
 */
if(!class_exists('ytChan')){
    class ytChan{
        public function __construct()
        {
            define('YCD_PATH', plugin_dir_path(__FILE__));
            define('YCD_URL', plugin_dir_url(__FILE__));
            require_once(YCD_PATH .'/vendor/autoload.php');
        }
        public function initialize()
        {
            include_once YCD_PATH . 'includes/utilities.php';
            include_once YCD_PATH . 'includes/options_page.php';
            include_once YCD_PATH . 'includes/playlist.php';

        }
    }
   $ytChan = new ytChan;
   $ytChan->initialize();
}
/**
 * Require the GitHub_Plugin_Updater class.
 *
 * Ideally use an autoloader, but for the sake of functionality we are using require_once here.
 */
require_once YCD_PATH . 'updater.php';
use GitHub_Plugin_Updater;
( new GitHub_Plugin_Updater( plugin_basename( __FILE__ ), '1.0.0', 'https://github.com/HoussemMereghni/yt-channel-disp.git' ) )->init();