<?php
/**
 * Define shortcode
 * Enqueing styles
 * including plugin frontend content
 * */
add_shortcode('YCD_channel', 'show_playlist');
add_action('wp_enqueue_scripts', 'enqueue_custom_scripts');
function enqueue_custom_scripts()
{
    wp_enqueue_style('ycd-scripts', YCD_URL . '/assets/css/ycd-style.css');
}
function show_playlist()
{
 include YCD_PATH . '/includes/templates/playlist.php';
}

