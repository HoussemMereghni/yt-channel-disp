<?php
/**
 * Loading Carbon Fields library 
 * Used to create options page
 * 
 * */
use Carbon_Fields\Container;
use Carbon_Fields\Field;

add_action('after_setup_theme', 'load_carbon_fields');
add_action('carbon_fields_register_fields', 'create_options_page');
function load_carbon_fields()
{
   \Carbon_Fields\Carbon_Fields::boot();
} 

function create_options_page()
{
    Container::make( 'theme_options', __( 'YCD' ) )->set_icon( 'dashicons-playlist-video' )
    ->add_fields( array(
        Field::make( 'text', 'ycd_channel_url', __( 'Youtube Channel URL' ) )->set_help_text( 'Youtube Channel url taken from yt' )
        ,

    ) );
}