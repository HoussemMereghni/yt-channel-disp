<div id="ycdContainer" class="scrollContainer"></div>
<script>
    const channel = <?php echo json_encode(carbon_get_theme_option( 'ycd_channel_url' )); ?>;
    const container = document.getElementById("ycdContainer");
    for(let i=1; i<=10; i++){
    const node = document.createElement('div');
    node.innerHTML = '<iframe width="450" height="250" src="https://www.youtube.com/embed?max-results=3&controls=0&showinfo=0&rel=0&listType=user_uploads&list='+channel+'&index='+i+'" frameborder="0" allowfullscreen></iframe>';
    container.append(node);
   }
</script>